MVCPolyfils
=============

MVCPolyfils is a small set of classes that allow you to use views from a MVC project 
in a Xamarin project and have them both compiling and running the same files. 

For the complete guide, see [MichaelRidland.com](http://www.michaelridland.com)
